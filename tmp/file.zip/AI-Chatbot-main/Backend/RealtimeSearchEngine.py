from googlesearch import search
from groq import Groq
from json import load, dump
import datetime
from dotenv import dotenv_values
import yfinance as yf
import requests

# Load environment variables
env_vars = dotenv_values(".env")
Username = env_vars.get("Username")
Assistantname = env_vars.get("Assistantname")
GroqAPIKey = env_vars.get("GroqAPIKey")
OpenWeatherMapAPIKey = env_vars.get("OpenWeatherMapAPIKey")
NewsAPIKey = env_vars.get("NewsAPIKey")

# Initialize Groq client
client = Groq(api_key=GroqAPIKey)

# System instruction for the chatbot
System = f"""Hello, I am {Username}, You are a very accurate and advanced AI chatbot named {Assistantname} which has real-time up-to-date information from the internet.
*** Provide Answers In a Professional Way, make sure to add full stops, commas, question marks, and use proper grammar.***
*** Just answer the question from the provided data in a professional way. ***"""

# Load or create chat log
try:
    with open(r"Data\ChatLog.json", "r") as f:
        messages = load(f)
except:
    with open(r"Data\ChatLog.json", "w") as f:
        dump([], f)

def GoogleSearch(query):
    try:
        results = list(search(query, advanced=True, num_results=5))
        if not results:
            return f"No search results found for '{query}'. Please try a different query or check your internet connection."
        
        Answer = f"The search results for '{query}' are:\n[start]\n"
        for i in results:
            Answer += f"Title: {i.title}\nDescription: {i.description}\nURL: {i.url}\n\n"
        Answer += "[end]"
        return Answer
    except Exception as e:
        return f"An error occurred during the search: {e}"

def GetStockPrice(ticker):
    try:
        stock = yf.Ticker(ticker)
        history = stock.history(period="1d")
        
        if history.empty:
            return f"No data found for ticker '{ticker}'. It may be invalid or delisted."
        
        price = history["Close"].iloc[-1]
        return f"The current stock price of {ticker.upper()} is ${price:.2f}."
    except Exception as e:
        return f"An error occurred while fetching the stock price: {e}"

def GetWeather(city):
    try:
        url = f"http://api.openweathermap.org/data/2.5/weather?q={city}&appid={OpenWeatherMapAPIKey}&units=metric"
        response = requests.get(url)
        data = response.json()
        if data["cod"] != 200:
            return f"Could not fetch weather data for {city}. Please check the city name and try again."
        
        weather = data["weather"][0]["description"]
        temperature = data["main"]["temp"]
        humidity = data["main"]["humidity"]
        return f"The current weather in {city} is {weather} with a temperature of {temperature}°C and humidity of {humidity}%."
    except Exception as e:
        return f"An error occurred while fetching the weather: {e}"

def GetNews(topic):
    try:
        url = f"https://newsapi.org/v2/everything?q={topic}&apiKey={NewsAPIKey}"
        response = requests.get(url)
        data = response.json()
        if data["status"] != "ok":
            return f"Could not fetch news for {topic}. Please try again later."
        
        articles = data["articles"][:5]  # Get top 5 articles
        Answer = f"Here are the latest news articles about '{topic}':\n[start]\n"
        for article in articles:
            Answer += f"Title: {article['title']}\nDescription: {article['description']}\nURL: {article['url']}\n\n"
        Answer += "[end]"
        return Answer
    except Exception as e:
        return f"An error occurred while fetching the news: {e}"

def AnswerModifier(Answer):
    lines = Answer.split('\n')
    non_empty_lines = [line.strip() for line in lines if line.strip()]
    modified_answer = '\n'.join(non_empty_lines)
    return modified_answer

def Information():
    current_date_time = datetime.datetime.now()
    day = current_date_time.strftime("%A")
    date = current_date_time.strftime("%d")
    month = current_date_time.strftime("%B")
    year = current_date_time.strftime("%Y")
    hour = current_date_time.strftime("%H")
    minute = current_date_time.strftime("%M")
    second = current_date_time.strftime("%S")
    data = "Use This Real-time Information if needed:\n"
    data += f"Day: {day}\n"
    data += f"Date: {date}\n"
    data += f"Month: {month}\n"
    data += f"Year: {year}\n"
    data += f"Time: {hour} Hours, {minute} Minutes, {second} Seconds.\n"
    return data

def RealtimeSearchEngine(prompt):
    global messages

    with open(r"Data\ChatLog.json", "r") as f:
        messages = load(f)

    messages.append({"role": "user", "content": prompt})

    # Check if the prompt is about stock prices
    if "stock price" in prompt.lower():
        company = prompt.lower().replace("stock price of", "").strip()
        ticker_map = {
            "google": "GOOGL",
            "apple": "AAPL",
            "microsoft": "MSFT",
            "amazon": "AMZN",
            "tesla": "TSLA",
            "mrf": "MRF.NS",
        }
        ticker = ticker_map.get(company, company.upper())
        response = GetStockPrice(ticker)
        messages.append({"role": "assistant", "content": response})
        with open(r"Data\ChatLog.json", "w") as f:
            dump(messages, f, indent=4)
        return response

    # Check if the prompt is about weather
    if "weather" in prompt.lower():
        city = prompt.lower().replace("weather in", "").strip()
        response = GetWeather(city)
        messages.append({"role": "assistant", "content": response})
        with open(r"Data\ChatLog.json", "w") as f:
            dump(messages, f, indent=4)
        return response

    # Check if the prompt is about news
    if "news" in prompt.lower():
        topic = prompt.lower().replace("news about", "").strip()
        response = GetNews(topic)
        messages.append({"role": "assistant", "content": response})
        with open(r"Data\ChatLog.json", "w") as f:
            dump(messages, f, indent=4)
        return response

    # Fallback to Google search for other queries
    search_results = GoogleSearch(prompt)
    messages.append({"role": "system", "content": search_results})

    if "No search results found" in search_results or "error occurred" in search_results:
        fallback_response = (
            f"I couldn't find real-time information for '{prompt}'. "
            "Please try a different query or check your internet connection."
        )
        messages.append({"role": "assistant", "content": fallback_response})
        with open(r"Data\ChatLog.json", "w") as f:
            dump(messages, f, indent=4)
        return fallback_response

    realtime_info = Information()
    messages.append({"role": "system", "content": realtime_info})

    completion = client.chat.completions.create(
        model="llama3-70b-8192",
        messages=messages,
        max_tokens=2048,
        temperature=0.7,
        top_p=1,
        stream=True,
        stop=None
    )

    Answer = ""
    for chunk in completion:
        if chunk.choices[0].delta.content:
            Answer += chunk.choices[0].delta.content
    Answer = Answer.strip().replace("</s>", "")

    messages.append({"role": "assistant", "content": Answer})

    with open(r"Data\ChatLog.json", "w") as f:
        dump(messages, f, indent=4)

    return AnswerModifier(Answer=Answer)

if __name__ == "__main__":
    while True:
        prompt = input("Enter your Question (or type 'exit' to quit): ")
        if prompt.lower() == "exit":
            break
        print(RealtimeSearchEngine(prompt))