from groq import Groq  # Importing the groq library to use its API
from json import load, dump  # Importing functions to read and write JSON files
import datetime  # Importing datetime module for real time date and time information
# Import dotenv to load enviroment variables a .env file
from dotenv import dotenv_values
# Load enviroment variable from the .env file
env_vars = dotenv_values(".env")
# Retrieve specfic enviroment variables for username,assistant name,and API Key.
Username = env_vars.get("Username")
Assistantname = env_vars.get("Assistantname")
GroqAPIKey = env_vars.get("GroqAPIKey")
# Initialize the graq client using the provided API Key
client = Groq(api_key=GroqAPIKey)

# Initialize an empty list to store user Messages
messages = []
# Define a system massage that provids context to the AI Chatbot about its role and behavior
System = f"""Hello, I am {Username}, You are a very accurate and advanced AI chatbot named {Assistantname} which also has real-time up-to-date information from the internet.
*** Do not tell time until I ask, do not talk too much, just answer the question.***
*** Reply in only English, even if the question is in Hindi, reply in English.***
*** Do not provide notes in the output, just answer the question and never mention your training data. ***
"""
# A list of system instructionsfor the chatbot
SystemChatBot = [
    {"role": "system", "content": System}
]
# Attempt to load the chatlog from the JSON file
try:
    with open(r"Data\ChatLog.json", "r")as f:
        messages = load(f)  # Load existing messages from the chat logs.
except FileNotFoundError:
    # If the file dosenot exist,create a empty JOSN file to store chatlogs
    with open(r"Data\ChatLog.json", "w")as f:
        dump([], f)

# Function to get real-time date and time information


def RealtimeInformation():
    current_date_time = datetime.datetime.now()  # Get the current date and time
    day = current_date_time.strftime("%A")  # Day of the week
    date = current_date_time.strftime("%d")  # Day of the month
    month = current_date_time.strftime("%B")  # Full month name
    year = current_date_time.strftime("%Y")  # Year
    hour = current_date_time.strftime("%H")  # Hour in 24H Formet
    minute = current_date_time.strftime("%M")  # Minute
    second = current_date_time.strftime("%S")  # Second


   # Formet the information into a string
    data = f"please use this real-time information if needed,\n"
    data += f"Day:{day}\nDate:{date}\nMonth:{month}\nYear:{year}\n"
    data += f"Time:{hour} Hours:{minute} Minutes: {second} Seconds.\n"
    return data

# Function to modify the chatbot's response for better formatting.abs


def AnswerModifier(Answer):
    lines = Answer.split('\n')  # split the response into lines
    # remove empty lines
    non_empty_lines = [line for line in lines if line.strip()]
    # joinds the cleaned lines together
    modified_answer = '\n'.join(non_empty_lines)
    return modified_answer


# main chatbot function handle user queries
def ChatBot(Query):
    """ This Function sends the users query to the chatbot and returns the AI's Response. """
    try:
        # load the existing chat loges from the JSON file.
        with open(r"Data\ChatLog.json", "r")as f:
            messages = load(f)
        # append the user query to the message list
        messages.append({"role": "user", "content": f"{Query}"})
        #make a request to the Groq API for a response
        completion = client.chat.completions.create(
           model='llama3-70b-8192', #Spicfy the Ai model to use
           messages=SystemChatBot + [{"role": "system", "content": RealtimeInformation()}] + messages,
           max_tokens=1024,#limit the miximum tokens in the response
           temperature=0.7,#Adjust response randomness(higher means more random)
           top_p=1,#use necules sampling to control diversity
           stream=True,#Enable streaming response
           stop=None#Allow model to determine when to stop
        )
        Answer=" "#Initialize an empty string to store the AI'S Response
        #Process the streamed response chunks
        for chunk in completion:
            if chunk.choices[0].delta.content:#Check if there contact in the current chanks
                Answer += chunk.choices[0].delta.content#Append the content to the answer
        Answer = Answer.replace("</s>","")#Clean up any unwanted token from the response
         #Append the chatbot response to the message list
        messages.append({"role":"assistant","content":Answer})
        #Save the  updated chat logs to the JSON file
        with open(r"Data\ChatLog.json","w")as f:
            dump(messages,f,indent=4)
        #Return the formatted response
        return AnswerModifier(Answer=Answer)
    except Exception as e:
        #Handle error by printing the exception and resetting the chat locks
        print(f"Error:{e}")
        with open(r"Data\ChatLog.json","w")as f:
            dump([],f,indent=4)
        return ChatBot(Query)#Retry the qurious after resetting the logs           
#Main Program Entry point
if __name__ =="__main__":
    while True:
        user_input = input("Enter Your Question: ")#Prompt the user for a question
        print(ChatBot(user_input))#Call the chatbot function and print the response